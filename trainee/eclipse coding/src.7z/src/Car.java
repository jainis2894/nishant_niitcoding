
public interface Car {

}
