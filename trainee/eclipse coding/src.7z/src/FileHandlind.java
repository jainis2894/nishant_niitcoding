import java.io.*;
public class FileHandlind {
	
	public static void main(String args[])
	{
		//File f=new File();
		
	}

}
