
public class ConnectDb
{
	//static Connection con;
	
}
