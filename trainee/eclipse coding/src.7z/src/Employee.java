
public class Employee {
	private String name;
	private int age;
	private double salary;
	private int id;
	String getName()
	{
		return this.name;
	}
	int getAge()
	{
		return this.age;
	}
	double getSalary()
	{
		return this.salary;
	}
	int getId()
	{
		return this.id;
	}
	void setName(String name)
	{
		this.name=name;
	}
	void setSalary(double sal)
	{
		this.salary=sal;
	}
	void setId(int id)
	{
		this.id=id;
	}
	void setAge(int age)
	{
		this.age=age;
	}
	
	

}
