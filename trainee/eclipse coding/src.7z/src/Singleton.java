
public class Singleton {
	

}
